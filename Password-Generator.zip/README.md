# Password Generator Firefox/Add-on

Firefox/Add-on: [Password Generator](https://addons.mozilla.org/it/firefox/addon/aleff-password-generator/)

Icons: [Shield icons created by Freepik - Flaticon](https://www.flaticon.com/free-icons/shield)

Discussione su Inforge: https://www.inforge.net/forum/threads/password-generator-firefox-and-chrome-add-on-opensource-free.613477/

![](https://github.com/aleff-github/Password-Generator-Firefox-Add-on/blob/main/images/1.png)

![](https://github.com/aleff-github/Password-Generator-Firefox-Add-on/blob/main/images/2.png)

![](https://github.com/aleff-github/Password-Generator-Firefox-Add-on/blob/main/images/3.png)

![](https://github.com/aleff-github/Password-Generator-Firefox-Add-on/blob/main/images/4.png)
